package com.example.oragnization.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeRequest {

	@NotNull(message="name should not be null")
	@NotEmpty(message="name shoul not be empty")
	private String empName;
    private String location;
    @Min(18)
    @Max(60)
   
	private int age;
	@NotBlank(message="dept should not be blank")
	@Email(message="it should be in email format")
	@Pattern(
			regexp="^[A-Za-z0-9._%+-]+@gmail\\.com$",
			message="email is inappropriate")
	private String empEmail;
	 @Positive(message="dept should be positive")
	private int deptId;
	private String phoneNumber;
	

}
