package com.example.oragnization.controller;

import com.example.oragnization.service.EmployeeImp;

import jakarta.validation.Valid;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.oragnization.dto.EmployeeRequest;
import com.example.oragnization.dto.EmployeeResponse;
import com.example.oragnization.entity.Employee;
import com.example.oragnization.repository.EmployeeRepository;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	private EmployeeImp employeeService;

	// localhost:5090/employee
	@GetMapping("/")
	public ResponseEntity<List<EmployeeResponse>> getAllEmployee() {

		List<EmployeeResponse> emp = employeeService.getAllEmp();
		if (CollectionUtils.isEmpty(emp)) {
			return ResponseEntity.noContent().build();
		}

		System.out.println("cant fetch all the employee");
		return new ResponseEntity<>(emp, HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<EmployeeResponse> getEmployeeById(@PathVariable int id) {
		try {
			EmployeeResponse empResponse = employeeService.getById(id);
			return new ResponseEntity<>(empResponse, HttpStatus.OK);

		} catch (RuntimeException e) {

			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/")
	public ResponseEntity<EmployeeResponse> createEmployee(@RequestBody @Valid EmployeeRequest empRequest) {

		EmployeeResponse emp = employeeService.saveEmployee(empRequest);
		if (emp == null) {
			return new ResponseEntity(emp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<>(emp, HttpStatus.CREATED);
	}

	@PutMapping("/{id}")
	public ResponseEntity<EmployeeResponse> updateEmployee(@PathVariable int id,@RequestBody EmployeeRequest request) {

		EmployeeResponse response=employeeService.updateEmployee(id,request);

		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable int id) {

		if (employeeService.existsById(id)) {

			employeeService.deleteById(id);
			return ResponseEntity.status(HttpStatus.OK).body("Deleted");
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Not Found");

		}
	}

}
