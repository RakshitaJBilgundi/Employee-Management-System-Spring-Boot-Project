package com.example.oragnization.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.oragnization.entity.Department;

import com.example.oragnization.service.DepartmentService;
import com.example.oragnization.service.DepartmentServiceImpl;

@RestController
public class DepartmentController {
	@Autowired
	private DepartmentServiceImpl Departmentservice;

//local:5091/department
	@GetMapping("/department")
	public List<Department> getAllDepartment() {

		return Departmentservice.getAllDepartment();

	}

	@GetMapping("/department/{id}")
	public Department getDepartmentById(@PathVariable int id) {

		return Departmentservice.getById(id);
	}

	@PostMapping("/department/add")
	@ResponseStatus(code = HttpStatus.CREATED)
	public Department createDepartment(@RequestBody Department dept) {
		return Departmentservice.saveDepartment(dept);
	}

	@PutMapping("/department/update/{id}")
	public Department updateDepartment(int id) {
		Department dept = Departmentservice.getById(id);

		if (dept != null) {
			dept.setDeptId(10);
			dept.setdeptName("Cashier");
			return Departmentservice.saveDepartment(dept);
		}
		return null;
	}

	@DeleteMapping("/department/delete/{id}")
	public String deleteDepartment(@PathVariable int id) {
		if (Departmentservice.existsById(id)) {
			Departmentservice.deleteById(id);
			return "Department and its employee deleted";
		}
		return " Department Not found";
	}

}