package com.example.oragnization.service;

import java.util.List;

import com.example.oragnization.entity.Department;
import com.example.oragnization.entity.Employee;

public interface DepartmentService {
	public List<Department> getAllDepartment();

	public Department getById(int id);

	public Department saveDepartment(Department dept);

	public void deleteById(int id);

	public boolean existsById(int id);

}
