package com.example.oragnization.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import com.example.oragnization.dto.EmployeeRequest;
import com.example.oragnization.dto.EmployeeResponse;
import com.example.oragnization.entity.Department;
import com.example.oragnization.entity.Employee;
import com.example.oragnization.repository.DepartmentRepository;
import com.example.oragnization.repository.EmployeeRepository;

import lombok.extern.slf4j.Slf4j;
import java.util.Optional;

@Service
@Slf4j
public class EmployeeImp implements EmployeeService {
	@Autowired
	private DepartmentRepository deptrepo;

	@Autowired
	private EmployeeRepository employeeRepo;
	@Autowired
	private ModelMapper mapper;

	@Override
	public EmployeeResponse saveEmployee(EmployeeRequest employeeRequest) {
		try {
			Employee emp = mapper.map(employeeRequest, Employee.class);
			Department dept = deptrepo.findById(employeeRequest.getDeptId())
					.orElseThrow(() -> new RuntimeException("Department not found"));
			emp.setDepartment(dept);
			Employee saveEmp = employeeRepo.save(emp);
			EmployeeResponse resp = new EmployeeResponse();
			resp.setEmpName(saveEmp.getEmpName());
			resp.setEmpId(saveEmp.getEmpId());
			resp.setEmpEmail(saveEmp.getEmpEmail());
			resp.setLocation(saveEmp.getLocation());
			//resp.setPhoneNumber(saveEmp.getPhoneNumber());

			if (saveEmp.getDepartment() != null) {
//				resp.setDeptName(saveEmp.getDepartment().getdeptName());
//				resp.setDeptId(saveEmp.getDepartment().getDeptId());
			}
			return resp;
		} catch (RuntimeException r) {
			log.error("failed to save the employee",r);
			throw new RuntimeException("unable to save employee");
		}
	}

	@Override
	public EmployeeResponse updateEmployee(int id, EmployeeRequest employeeRequest) {

		try {

			Employee existingEmployee = employeeRepo.findById(id)
					.orElseThrow(() -> new RuntimeException("Employee not found"));

			existingEmployee.setEmpName(employeeRequest.getEmpName());

			existingEmployee.setLocation(employeeRequest.getLocation());

			existingEmployee.setAge(employeeRequest.getAge());

			existingEmployee.setEmpEmail(employeeRequest.getEmpEmail());
			existingEmployee.setPhoneNumber(employeeRequest.getPhoneNumber());

			Department dept = deptrepo.findById(employeeRequest.getDeptId())
					.orElseThrow(() -> new RuntimeException("Department not found"));

			existingEmployee.setDepartment(dept);

			Employee updatedEmployee = employeeRepo.save(existingEmployee);

			EmployeeResponse response = new EmployeeResponse();

			response.setEmpId(updatedEmployee.getEmpId());

			response.setEmpName(updatedEmployee.getEmpName());

			response.setEmpEmail(updatedEmployee.getEmpEmail());
			
			response.setLocation(updatedEmployee.getLocation());
			//response.setPhoneNumber(updatedEmployee.getPhoneNumber());

			if (updatedEmployee.getDepartment() != null) {

				//response.setDeptId(updatedEmployee.getDepartment().getDeptId());

				//response.setDeptName(updatedEmployee.getDepartment().getdeptName());
			}

			return response;

		} catch (Exception e) {

			log.error("Failed to update employee", e);

			throw new RuntimeException("Unable to update employee");
		}
	}

	@Override
	public List<EmployeeResponse> getAllEmp() {
		try {
			List<Employee> emp = employeeRepo.findAll();
			List<EmployeeResponse> empList = emp.stream().map(employee -> {

				EmployeeResponse response = new EmployeeResponse();

				response.setEmpId(employee.getEmpId());
				response.setEmpName(employee.getEmpName());
				response.setEmpEmail(employee.getEmpEmail());
				response.setLocation(employee.getLocation());
				//response.setPhoneNumber(employee.getPhoneNumber());
				

				if (employee.getDepartment() != null) {

//					response.setDeptId(employee.getDepartment().getDeptId());
//
//					response.setDeptName(employee.getDepartment().getdeptName());

				}

				return response;

			}).toList();
			return empList;
		} catch (RuntimeException r) {
			r.printStackTrace();
			throw r;
		}
	}

	@Override
	public EmployeeResponse getById(int id) {
		try {
			Employee emp = employeeRepo.findById(id).orElseThrow(() -> new RuntimeException("check your id"));
			EmployeeResponse empResponse = new EmployeeResponse();

			empResponse.setEmpId(emp.getEmpId());
			empResponse.setEmpName(emp.getEmpName());
			empResponse.setEmpEmail(emp.getEmpEmail());

			if (emp.getDepartment() != null) {

//				empResponse.setDeptName(emp.getDepartment().getdeptName());
//				empResponse.setDeptId(emp.getDepartment().getDeptId());
			}
			;
			return empResponse;
		} catch (RuntimeException e) {
			log.error("failed to get by id");
			throw e;
		}
	}

	@Override
	public boolean deleteById(int id) {
		try {
			Optional<Employee> emp = employeeRepo.findById(id);
			if (emp.isPresent()) {
				employeeRepo.deleteById(id);
				return true;
			}
			return false;
		} catch (RuntimeException r) {
			log.error("error to delete by id");
			return false;
		}
	}

	@Override
	public boolean existsById(int id) {
		try {
			return employeeRepo.existsById(id);

		} catch (RuntimeException r) {
			log.error("failed to exist by id");
			throw new RuntimeException("check the id exist");
		}

	}

}
