package com.example.oragnization.validation;

public @interface Phonenumber {

}
