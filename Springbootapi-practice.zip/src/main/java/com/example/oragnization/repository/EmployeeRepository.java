package com.example.oragnization.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.oragnization.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}

