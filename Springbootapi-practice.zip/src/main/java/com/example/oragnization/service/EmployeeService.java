package com.example.oragnization.service;

import java.util.List;

import com.example.oragnization.dto.EmployeeRequest;
import com.example.oragnization.dto.EmployeeResponse;
import com.example.oragnization.entity.Employee;

public interface EmployeeService {
//DTO->ENTITY
	
	public EmployeeResponse saveEmployee(EmployeeRequest EmployeeRequest);
	public EmployeeResponse updateEmployee(int id,EmployeeRequest EmployeeRequest);
	
	//ENTITY->DTO

	public List<EmployeeResponse> getAllEmp();

	public EmployeeResponse getById(int id);

	public boolean deleteById(int id);

	public boolean existsById(int id);

}
