package com.example.oragnization.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.oragnization.entity.Department;
import com.example.oragnization.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentRepository repo;

	public List<Department> getAllDepartment() {
		try {
			return repo.findAll();
		} catch (Exception e) {
			System.out.println("error fetching all department");
			return null;
		}
	}

	public Department getById(int id) {
		try {
			return repo.findById(id).orElse(null);
		} catch (Exception e) {
			System.out.println(" failed to fetch by the id check the correct department");
			return null;
		}

	}

	public Department saveDepartment(Department dept) {
		try {
			return repo.save(dept);
		} catch (Exception e) {
			System.out.println("failed to save the department");
			return null;
		}
	}

	public void deleteById(int id) {
		try {
			repo.deleteById(id);
		} catch (Exception e) {
			System.out.println("failed to delete by id");
		}
	}

	public boolean existsById(int id) {
		try {
			return repo.existsById(id);
		} catch (Exception e) {
			System.out.println("Doesnt exist by id");
			throw new RuntimeException("doesnt exist by id");
		}
	}
}
